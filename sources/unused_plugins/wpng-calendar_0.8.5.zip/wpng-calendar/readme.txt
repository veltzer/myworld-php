=== wpng-calendar ===
Contributors: L1Jockeys
Donate link: http://code.google.com/p/wpng-calendar/
Tags: google, calendar
Requires at least: 2.3
Tested up to: 2.3
Stable tag: trunk

This plugin allows for the integration of a Google calendar into a Wordpress blog.

== Description ==

See the project page for more information:

http://code.google.com/p/wpng-calendar/
